

($) (document).ready(function () {
        //...Document

	

  // make radio button active
  $('.question input[type=radio]').change(function() {
    var label = $(this).parent();

    var question = $(this).parent().parent();
    var otherLabels = question.find('label');
    otherLabels.removeClass('active');
    label.toggleClass('active');
    /*
    console.log(otherAnswers);
    otherAnswers.each(function(){
      $(this).prop('checked', false);
    });
    */
  });

	var baseUrl = "http://www.soundjay.com/button/";
var audio = ["beep-01a.mp3"];

$('button.ci').click(function() {
  var i = $(this).attr('id').substring(1);           //get the index of button
  new Audio(baseUrl + audio[i - 1]).play();          //play corresponding audio
});
$(document).on('click','.question label',function() {
  new Audio(baseUrl + audio[0]).play();          //play corresponding audio
});




 // when submit button clicked
 $('#quiz-submit2').on('click', function(){

	 	var baseUrl = "../musik/clicking-rectangle.mp3";

$('.question').click(function() {
  var questionNum = $(this).attr('data-qnum').substring(1);
  
  //get the index of button
  new Audio(baseUrl + audio[i - 1]).play();          //play corresponding audio
});

   // create score var
     var score = 0;

   // loop through each question
   $('.question').each(function(){

		 var questionNum = $(this).attr('data-qnum');

     // remove the quiz-msg div
     $('.quiz-msg', this).remove();

     var correct = $(this).find(':checked[data-correct]').length;

		 var alertContent = "";



     // check answer
     if( correct == 1 ){
       // correct!
       //alert("correct!);
       var msgHTML = '<div class="quiz-msg correct">Correct!</div>';
       //$(this).append(msgHTML);


       // Add 1 to the score
       score++;


     }else{
       var msgHTML = '<div class="quiz-msg incorrect">Incorrect!</div>';

       // find the correct radio button and add class
       var correctRadio = $(this).find('input[data-correct]');
       var correctRadioLabel = correctRadio.parent();
       correctRadioLabel.addClass('correct');
     }

		 alertContent += msgHTML;
	   	
	   
	   
		 $.alert({
			 useBootstrap: false,
			 title: 'Question #'+questionNum,
			 content: alertContent,
			 onClose: function () {
				if(alertContent.indexOf("Incorrect!")>=0)
				 new Audio("./musik/clicking-incorrect.mp3").play();
			   else if(alertContent.indexOf("Correct!")>=0)
				 new Audio("./musik/clicking-correct.mp3").play();
			},
		 });

   });

   // output score
   $('#score').text(score);

 });

});// JavaScript Document
