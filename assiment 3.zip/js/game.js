$(document).ready(function(){


$(document).ready(function($) {
  var urlParams = new URLSearchParams(window.location.search);	
	var character = urlParams.get('character');
	$("#emoji").css("background-image","url('./pictures/"+character+".png')");
  // form submit
  $('#character-selection').on('karin', function(e){
    e.preventDefault();
    var character = $('[name=character-choice]:checked').val();
    //console.log(character);
    localStorage.setItem('character', character);
  });


  // retrieves first name from local storage
  // and inserts into header
  var characterLocal = localStorage.getItem('character');
  $('#user-character').text(characterLocal);

});
	
	
	
  function moveTornado(height){
    var tornado = $('#tornado');
    tornado.css('bottom', height+'%');
  }

  var gameInterval = setInterval(function(){
	   var value = $('#slider').slider('value');
	   $('#slider').slider('value',value+1);
	   moveTornado(value+1);
	   moveCharacter();
  },100);
	
  function moveCharacter(){
  	var lastPoint = $("#earth")[0].offsetWidth+$("#earth")[0].offsetLeft;
	var emojiLeft = $("#emoji")[0].offsetLeft;
	var emojiWidth = $("#emoji")[0].offsetWidth;  
	if((emojiLeft+emojiWidth)<lastPoint){
		$("#emoji").css("left",(emojiLeft+20)+"px");
	}else{
		
		clearInterval(gameInterval);
		$.alert({
			 useBootstrap: false,
			 title: 'Congratz',
			 content: "You win"
		 });
		//alert("You win");
	}
	 

	
	  
	 if(detectCollison()){
		 
		 clearInterval(gameInterval);
		$.alert({
			 useBootstrap: false,
			 title: 'OH',
			 content: "You LOSE"
		 });
	 }
	  
	  
  }
function detectCollison(){
	var tornadoTop = $("#tornado").offset().top;
	var tornadoLeft = $("#tornado")[0].offsetLeft;
	var tornadoRight = $("#tornado")[0].offsetLeft+$("#tornado")[0].offsetWidth;
	var tornadoBottom = $("#tornado").offset().top+$("#tornado")[0].offsetHeight;
	
	var emojiLeft = $("#emoji")[0].offsetLeft;
	var emojiTop = $("#emoji").offset().top;
	var emojiRight = $("#emoji")[0].offsetLeft+$("#emoji")[0].offsetWidth;
	var emojiBottom = $("#emoji").offset().top+$("#emoji")[0].offsetHeight;
	console.log(tornadoTop,emojiBottom);
	console.log((emojiRight>tornadoLeft) +"-"+ (emojiLeft<tornadoRight) +"-"+ (tornadoTop<emojiBottom));
	if(emojiRight>tornadoLeft && emojiLeft<tornadoRight && tornadoTop<emojiBottom){
		return true;
	}
	
	return false;
}
	
  $('#slider').slider({
    orientation: "vertical",
    max: 120,
    min: 0,
    slide: function(event, ui){
      //moveTornado();
      var slidePosition = ui.value;
      moveTornado(slidePosition);
    }
  });
	


  var startPosition = 40;

  $('#slider').slider("value", startPosition);
  moveTornado(startPosition);
	
 
  // create score var
  var score = 0;

  // difficulty value
  var difficultyVal = 1;
 
  
  
  // decrease pbar-progress height every 200ms
  var decreasePbarHeight = setInterval(function(){
    //console.log("decrease pbar");
    // decreawte pbar height
    $('#ui.widget').height("-="+difficultyVal);
  }, 50);
  
	var element=document.getElementById('emoji')
	var container=document.getElementById('game-stage')
	
	var guyleft = 0;
	
	function anim(e) {
		
		if (e.keyCode==39) {
			guyleft +=2;
			guy.style.left = guyLeft + 'px' ;
			if(guyleft >=600) {
				guyleft -=2;
			}
		}
		if (e.keycode==37) {
			guyleft -=2;
			guy.style.left = guyLeft + 'px' ;
			if(guyleft <=0) {
				guyleft +=2;
			}
		}
	}
  
  // button trigger
  $('#trigger').on('click', function(){
    
    // 1. get height of container
    var pbarConHeight = $('.slider.container').height();
    //console.log(pbarConHeight);
    
    // 2. figure out 10% of container height
    // 2.1 store as pbarHeightGrow
    var pbarHeightGrow = pbarConHeight * 0.1;
    //console.log(pbarHeightGrow);
    
    // 3.1 check to see if new progress bar height is equal to
    // or greater than the contatiner height
    var newPbarHeight = $('.slider.container').height() + pbarHeightGrow;
    //console.log(newPbarHeight);
    if(newPbarHeight <= pbarConHeight){
      // game not finished yet, increase pbar-progress height
      $('.slider.container').height("+="+pbarHeightGrow);
    }else{
      // game finished!
      // set pbar-progress height to full height of container
      $('.slider.container').height(pbarConHeight);
      // stop decreasing pbar height (stop the interval!)
      clearInterval(decreasePbarHeight);
      // display success message
      alert("game complete!");
      
      // stop the stopwatch
      clearInterval(stopwatch);
    }
    
    
     // 4. increase score by 10
     score = score + 10;
    
     // 5. output the score on screen
     $('#score').text(score);
  });
  

});
